<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ae14587c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\x65\x6e\147\x6c\151\163\150\x2d\x61\162\x74\151\x63\x6c\145\163")->muuwuqssqkaieqge(__("\105\x6e\147\x6c\151\163\150\x20\101\x72\x74\x69\x63\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\x6e\x67\x6c\151\x73\x68\40\101\162\164\151\143\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\144\x61\163\150\x69\143\x6f\x6e\163\x2d\x61\144\x6d\x69\x6e\55\160\x6f\x73\164"); } }
