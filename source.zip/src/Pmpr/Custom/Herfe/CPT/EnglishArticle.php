<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x65\x6e\147\x6c\x69\x73\150\x2d\x61\162\164\151\x63\x6c\x65\x73")->muuwuqssqkaieqge(__("\x45\156\x67\x6c\x69\x73\x68\40\101\x72\x74\151\143\x6c\x65\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\147\x6c\x69\x73\150\x20\x41\162\164\151\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\163\150\x69\x63\x6f\x6e\163\55\x61\x64\x6d\x69\x6e\55\160\x6f\x73\x74"); } }
