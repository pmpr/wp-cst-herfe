<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92f25ffc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\151\162\x61\156\151\141\156\x2d\x63\157\156\x74\145\x6d\160\157\162\x61\162\171\x2d\x61\x72\164")->muuwuqssqkaieqge(__("\x45\x6e\x67\154\x69\163\150\40\101\x72\164\151\143\154\145\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\105\x6e\x67\154\x69\x73\150\40\x41\x72\x74\x69\143\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\144\x61\x73\150\151\143\x6f\156\163\x2d\x61\x64\155\x69\156\x2d\x70\x6f\x73\x74"); } }
