<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\151\162\x61\x6e\x69\x61\x6e\55\x63\x6f\156\164\145\x6d\160\157\162\141\162\171\x2d\x61\x72\x74")->muuwuqssqkaieqge(__("\105\x6e\147\154\151\x73\150\x20\x41\x72\x74\x69\x63\x6c\x65\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\x67\154\x69\163\150\40\101\x72\164\x69\143\x6c\x65", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\163\150\151\143\x6f\x6e\163\x2d\x61\144\155\x69\x6e\x2d\160\157\163\x74"); } }
