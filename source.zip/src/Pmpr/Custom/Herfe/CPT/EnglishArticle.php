<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c4dccd5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\x65\156\147\x6c\151\x73\150\55\x61\162\x74\x69\143\154\x65\163")->muuwuqssqkaieqge(__("\x45\x6e\x67\x6c\x69\163\x68\40\x41\x72\x74\151\143\154\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\156\147\154\x69\x73\x68\40\101\162\x74\x69\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\163\150\151\143\x6f\x6e\163\x2d\x61\x64\x6d\151\156\x2d\160\157\163\164"); } }
