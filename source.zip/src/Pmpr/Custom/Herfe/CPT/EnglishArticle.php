<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587693f468             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\151\x72\x61\x6e\151\x61\156\x2d\x63\157\156\164\x65\155\160\157\162\141\162\x79\55\141\x72\x74")->muuwuqssqkaieqge(__("\105\156\147\154\151\x73\150\x20\x41\162\164\x69\143\154\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\x67\x6c\x69\163\150\40\101\162\164\x69\143\154\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\x73\150\x69\x63\x6f\156\x73\55\141\144\155\151\x6e\x2d\160\x6f\163\x74"); } }
