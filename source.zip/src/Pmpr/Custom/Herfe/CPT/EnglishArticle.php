<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14fbc47f5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\x65\156\x67\x6c\151\163\150\55\x61\162\164\151\143\x6c\145\163")->muuwuqssqkaieqge(__("\x45\156\147\x6c\x69\x73\x68\40\101\x72\164\x69\x63\x6c\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\x6e\x67\x6c\151\163\150\x20\x41\162\164\x69\143\154\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\x73\150\x69\x63\157\x6e\x73\x2d\141\144\155\x69\156\x2d\160\157\163\164"); } }
