<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebf66cbec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\x65\x6e\147\x6c\151\163\x68\55\141\x72\164\x69\x63\x6c\x65\x73")->muuwuqssqkaieqge(__("\105\156\147\154\x69\163\150\x20\x41\162\164\x69\x63\154\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\156\147\154\151\x73\x68\x20\101\162\164\151\143\154\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\x61\x73\150\151\143\157\x6e\163\55\141\x64\x6d\151\x6e\55\160\x6f\x73\x74"); } }
