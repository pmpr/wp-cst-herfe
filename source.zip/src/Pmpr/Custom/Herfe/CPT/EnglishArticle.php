<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd820af53             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\156\x67\154\151\163\x68\55\x61\162\164\151\x63\x6c\145\163")->muuwuqssqkaieqge(__("\x45\156\x67\154\151\x73\150\40\101\162\x74\x69\143\154\x65\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\x67\154\151\x73\150\40\101\x72\x74\x69\x63\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\x73\x68\x69\143\x6f\156\x73\55\141\x64\x6d\x69\x6e\55\160\x6f\x73\x74"); } }
