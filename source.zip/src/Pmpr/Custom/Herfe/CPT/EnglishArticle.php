<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\151\x72\x61\156\151\141\156\x2d\143\157\x6e\x74\x65\x6d\160\x6f\x72\141\x72\x79\x2d\x61\x72\164")->muuwuqssqkaieqge(__("\105\156\147\154\151\163\x68\40\x41\x72\164\151\143\x6c\x65\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\147\x6c\x69\163\150\40\x41\x72\x74\151\x63\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\x61\x73\x68\x69\143\157\156\x73\55\141\144\x6d\151\156\x2d\x70\157\163\164"); } }
