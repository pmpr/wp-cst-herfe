<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d24ec0e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x65\x6e\x67\154\151\163\150\55\x61\162\x74\151\143\154\x65\163")->muuwuqssqkaieqge(__("\x45\x6e\x67\154\x69\163\x68\x20\x41\162\164\151\x63\x6c\x65\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\147\x6c\x69\x73\x68\40\101\162\x74\151\x63\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\x61\x73\x68\151\x63\x6f\156\163\55\x61\144\x6d\151\x6e\55\x70\x6f\x73\164"); } }
