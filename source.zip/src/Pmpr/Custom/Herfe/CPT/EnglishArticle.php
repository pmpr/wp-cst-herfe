<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f0256adc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\145\156\x67\154\151\x73\x68\x2d\141\162\x74\151\x63\x6c\x65\x73")->muuwuqssqkaieqge(__("\105\156\x67\x6c\x69\x73\x68\40\101\x72\164\151\x63\154\145\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\147\154\151\x73\x68\40\x41\x72\164\x69\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\x73\x68\151\143\157\x6e\163\x2d\x61\144\155\151\x6e\55\x70\x6f\163\x74"); } }
