<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bd2e256d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x69\162\x61\156\151\x61\156\55\x63\x6f\156\x74\145\155\160\x6f\162\x61\162\x79\55\141\x72\164")->muuwuqssqkaieqge(__("\x45\x6e\147\154\151\x73\x68\40\101\x72\164\151\143\x6c\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\x67\154\x69\x73\150\x20\101\x72\164\x69\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\x61\163\150\151\143\x6f\x6e\x73\x2d\141\144\x6d\151\156\x2d\160\157\163\x74"); } }
