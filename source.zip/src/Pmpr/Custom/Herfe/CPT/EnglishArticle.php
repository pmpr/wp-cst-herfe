<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b9b5de1df             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\151\x72\141\156\x69\x61\x6e\55\x63\x6f\x6e\x74\x65\x6d\x70\x6f\x72\x61\162\171\x2d\141\162\x74")->muuwuqssqkaieqge(__("\x45\156\147\x6c\x69\163\150\x20\101\162\164\x69\143\x6c\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\147\154\151\163\150\x20\x41\x72\x74\151\143\x6c\x65", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\x73\x68\x69\143\157\156\163\x2d\x61\x64\x6d\151\156\x2d\x70\x6f\x73\x74"); } }
