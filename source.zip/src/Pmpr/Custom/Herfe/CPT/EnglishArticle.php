<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e04ac0261             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\x65\156\147\154\x69\x73\x68\55\141\162\x74\x69\143\x6c\145\163")->muuwuqssqkaieqge(__("\x45\156\147\x6c\x69\x73\150\40\x41\x72\x74\151\x63\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\147\x6c\151\163\150\40\x41\x72\164\151\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\x61\x73\150\151\143\x6f\156\x73\x2d\x61\144\x6d\151\x6e\55\160\x6f\x73\x74"); } }
