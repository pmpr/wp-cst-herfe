<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a5d85e80d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x69\162\x61\156\151\141\x6e\55\143\157\156\164\x65\x6d\160\x6f\x72\141\x72\x79\55\141\x72\164")->muuwuqssqkaieqge(__("\105\156\x67\154\151\x73\150\x20\101\x72\164\151\x63\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\x6e\x67\154\151\x73\x68\x20\x41\162\x74\151\143\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\163\150\x69\x63\157\156\163\x2d\141\144\155\151\156\55\160\157\x73\x74"); } }
