<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x65\156\147\x6c\151\163\150\x2d\141\162\164\x69\143\x6c\x65\x73")->muuwuqssqkaieqge(__("\105\x6e\x67\154\151\163\150\40\x41\x72\x74\151\x63\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\147\x6c\x69\163\x68\40\101\x72\x74\151\143\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\144\x61\163\x68\x69\x63\x6f\156\163\x2d\x61\x64\x6d\x69\x6e\x2d\160\157\x73\164"); } }
