<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a386d39c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, 'english-articles')->muuwuqssqkaieqge(__('English Articles', PR__CST__HERFE))->guiaswksukmgageq(__('English Article', PR__CST__HERFE))->yioesawwewqaigow('dashicons-admin-post'); } }
