<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x69\x72\141\156\x69\x61\x6e\x2d\x63\x6f\156\x74\145\155\x70\157\162\x61\x72\x79\x2d\x61\x72\x74")->muuwuqssqkaieqge(__("\x45\x6e\147\154\x69\163\x68\x20\x41\x72\164\151\x63\x6c\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\x6e\147\x6c\x69\x73\150\40\101\x72\x74\x69\143\x6c\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\163\150\x69\x63\157\156\163\x2d\x61\144\155\151\156\x2d\x70\x6f\163\164"); } }
