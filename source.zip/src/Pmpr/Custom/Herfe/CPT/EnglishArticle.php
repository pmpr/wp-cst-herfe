<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x69\x72\141\x6e\x69\141\156\55\143\157\156\x74\x65\155\160\x6f\x72\x61\x72\171\55\141\x72\x74")->muuwuqssqkaieqge(__("\105\x6e\147\154\x69\163\x68\40\101\x72\x74\151\143\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\x6e\x67\154\x69\163\150\x20\101\162\164\x69\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\163\x68\151\143\157\156\163\55\141\x64\x6d\151\156\55\x70\157\163\x74"); } }
