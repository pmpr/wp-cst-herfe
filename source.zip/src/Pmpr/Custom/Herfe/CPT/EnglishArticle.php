<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e5372b91             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x65\156\x67\154\x69\x73\x68\x2d\141\x72\164\x69\143\x6c\x65\163")->muuwuqssqkaieqge(__("\x45\156\x67\x6c\151\x73\x68\x20\101\162\x74\151\x63\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\147\x6c\x69\x73\x68\x20\101\162\164\151\x63\154\145", PR__CST__HERFE))->yioesawwewqaigow("\144\141\163\150\x69\x63\157\x6e\163\55\x61\144\x6d\151\x6e\x2d\x70\157\x73\164"); } }
