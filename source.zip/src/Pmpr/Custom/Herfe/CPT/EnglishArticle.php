<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707dc01428             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->ckwgqocyuaysggma(self::ouywiegeiyuaaawo, "\x69\x72\141\156\x69\x61\x6e\x2d\x63\x6f\156\164\x65\155\160\x6f\x72\x61\162\x79\x2d\x61\x72\x74")->muuwuqssqkaieqge(__("\x45\x6e\x67\154\151\x73\150\x20\101\x72\x74\x69\x63\x6c\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\x6e\147\154\151\x73\x68\x20\101\x72\x74\151\143\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\144\x61\x73\x68\151\x63\157\156\x73\x2d\x61\144\155\151\x6e\x2d\160\157\163\164"); } }
