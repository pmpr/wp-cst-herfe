<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Custom\Herfe\Container; class CPT extends Container { public function mameiwsayuyquoeq() { Product::symcgieuakksimmu(); Magazine::symcgieuakksimmu(); EnglishArticle::symcgieuakksimmu(); } }
