<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14fbc47f5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\x72\150\150\x73\165\x62\167\x70\x63\157\x6f\x6b\x69\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\165\x62\163\x63\x72\151\x70\x74\151\157\x6e\x5f\143\150\x65\x63\x6b\137\x61\143\143\x65\x73\x73\x5f\x72\x65\163\165\x6c\x74", [$this, "\145\x69\x6f\x67\x6f\x6b\165\145\153\163\x67\155\x6f\x6f\171\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto qogqewiwmwiwskgm; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { goto qiaqsassksqiuyae; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto cecuyayqoioasumi; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); cecuyayqoioasumi: qiaqsassksqiuyae: qogqewiwmwiwskgm: return $gwykaiwqgaycyggs; } }
