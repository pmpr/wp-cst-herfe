<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8972a818             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\x72\150\x68\163\165\x62\167\x70\x63\x6f\157\x6b\x69\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\x75\x62\x73\x63\162\x69\x70\x74\151\x6f\x6e\x5f\x63\x68\x65\x63\x6b\x5f\x61\x63\x63\x65\x73\163\x5f\x72\x65\163\x75\154\164", [$this, "\x65\x69\x6f\x67\157\153\x75\145\153\163\147\155\157\157\x79\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto ceiwqkyquikcemmo; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { goto uycesqqkoeamocgm; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto sqmoqymckwsogsqg; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); sqmoqymckwsogsqg: uycesqqkoeamocgm: ceiwqkyquikcemmo: return $gwykaiwqgaycyggs; } }
