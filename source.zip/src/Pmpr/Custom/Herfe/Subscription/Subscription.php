<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce711c12d1c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\x72\150\x68\x73\165\142\167\x70\143\157\x6f\153\151\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\x75\142\x73\x63\x72\151\160\164\x69\x6f\156\x5f\143\150\145\143\x6b\137\x61\143\x63\x65\163\x73\x5f\162\145\163\x75\x6c\x74", [$this, "\x65\x69\x6f\147\157\153\x75\145\153\163\x67\155\157\157\171\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto qogqewiwmwiwskgm; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { goto qiaqsassksqiuyae; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto cecuyayqoioasumi; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); cecuyayqoioasumi: qiaqsassksqiuyae: qogqewiwmwiwskgm: return $gwykaiwqgaycyggs; } }
