<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b57409bfc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\162\x68\x68\163\x75\142\x77\x70\x63\x6f\x6f\x6b\151\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\x75\x62\x73\143\x72\x69\x70\x74\151\x6f\156\x5f\143\150\145\x63\153\137\141\143\x63\x65\x73\163\x5f\162\145\x73\165\x6c\x74", [$this, "\145\x69\157\x67\x6f\153\x75\x65\x6b\163\147\x6d\157\x6f\x79\x6d"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto umgaesggesswoaqe; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto wwkgkaecgiwggcck; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto kciouyuaqkyqomam; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); kciouyuaqkyqomam: wwkgkaecgiwggcck: umgaesggesswoaqe: return $gwykaiwqgaycyggs; } }
