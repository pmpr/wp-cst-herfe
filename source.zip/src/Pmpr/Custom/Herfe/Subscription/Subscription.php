<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\x72\150\150\163\x75\x62\x77\160\x63\x6f\157\x6b\x69\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\x75\x62\163\143\162\x69\x70\164\151\x6f\x6e\137\x63\x68\x65\x63\153\137\x61\143\143\x65\163\x73\x5f\x72\x65\163\165\154\x74", [$this, "\145\151\157\x67\x6f\153\x75\x65\x6b\x73\x67\155\x6f\157\171\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto siecswkggyikqkga; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto goqmywuiicciasyk; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto oyiuyywyeoskckuw; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); oyiuyywyeoskckuw: goqmywuiicciasyk: siecswkggyikqkga: return $gwykaiwqgaycyggs; } }
