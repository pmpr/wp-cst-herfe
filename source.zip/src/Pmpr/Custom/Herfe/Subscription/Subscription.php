<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\162\x68\x68\163\165\142\x77\x70\143\157\x6f\x6b\x69\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\x75\142\x73\143\162\x69\x70\164\x69\x6f\x6e\x5f\x63\150\145\143\153\137\x61\143\x63\x65\163\163\x5f\x72\x65\163\x75\x6c\x74", [$this, "\145\x69\157\x67\x6f\x6b\165\145\153\x73\x67\155\157\x6f\171\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto siecswkggyikqkga; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto goqmywuiicciasyk; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto oyiuyywyeoskckuw; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); oyiuyywyeoskckuw: goqmywuiicciasyk: siecswkggyikqkga: return $gwykaiwqgaycyggs; } }
