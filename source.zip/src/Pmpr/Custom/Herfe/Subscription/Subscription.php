<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\x72\x68\x68\163\x75\x62\167\x70\x63\157\157\x6b\x69\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\165\142\163\x63\x72\x69\160\164\x69\x6f\x6e\x5f\143\150\145\x63\153\137\x61\143\x63\145\163\163\137\162\145\163\165\x6c\164", [$this, "\145\151\x6f\x67\x6f\153\x75\x65\153\163\x67\x6d\157\157\x79\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto siecswkggyikqkga; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto goqmywuiicciasyk; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto oyiuyywyeoskckuw; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); oyiuyywyeoskckuw: goqmywuiicciasyk: siecswkggyikqkga: return $gwykaiwqgaycyggs; } }
