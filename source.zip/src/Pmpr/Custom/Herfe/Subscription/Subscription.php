<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\162\x68\150\x73\x75\142\x77\x70\143\x6f\157\153\x69\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\165\x62\163\143\x72\x69\160\164\x69\x6f\156\x5f\143\x68\145\x63\x6b\x5f\141\x63\143\x65\x73\x73\x5f\x72\145\x73\165\154\164", [$this, "\x65\151\157\147\x6f\x6b\x75\145\x6b\163\147\x6d\x6f\x6f\x79\x6d"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto kosaqwikueyksqmw; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto mqkmcysgoiaouiwm; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto ykomgumacooyomsk; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); ykomgumacooyomsk: mqkmcysgoiaouiwm: kosaqwikueyksqmw: return $gwykaiwqgaycyggs; } }
