<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebf66cbec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\162\x68\x68\x73\165\x62\x77\x70\x63\x6f\x6f\153\151\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\x75\x62\x73\143\162\151\160\164\151\x6f\156\137\143\x68\145\143\x6b\x5f\141\x63\143\x65\163\163\137\x72\x65\x73\x75\154\x74", [$this, "\145\151\x6f\x67\x6f\x6b\165\x65\x6b\x73\147\155\157\157\171\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto qogqewiwmwiwskgm; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { goto qiaqsassksqiuyae; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto cecuyayqoioasumi; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); cecuyayqoioasumi: qiaqsassksqiuyae: qogqewiwmwiwskgm: return $gwykaiwqgaycyggs; } }
