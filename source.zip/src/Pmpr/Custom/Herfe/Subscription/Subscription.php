<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e5372b91             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\162\150\x68\x73\165\x62\167\160\x63\157\x6f\153\x69\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\165\142\x73\x63\x72\151\x70\164\151\x6f\156\137\x63\150\x65\143\x6b\x5f\141\x63\x63\145\163\163\x5f\x72\145\x73\x75\154\x74", [$this, "\x65\151\157\x67\157\153\165\145\153\163\147\155\x6f\157\x79\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto qsgqwyqaqiowkmco; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto gsygwgsiawgmqiyi; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto wwukgaquuyoissgy; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); wwukgaquuyoissgy: gsygwgsiawgmqiyi: qsgqwyqaqiowkmco: return $gwykaiwqgaycyggs; } }
