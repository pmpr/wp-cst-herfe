<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\162\x68\x68\x73\x75\x62\167\160\x63\x6f\x6f\x6b\x69\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\165\x62\x73\x63\162\x69\x70\164\x69\157\156\x5f\143\150\145\143\x6b\137\141\143\x63\x65\163\163\137\x72\x65\x73\165\x6c\164", [$this, "\x65\151\157\x67\157\153\x75\x65\x6b\163\x67\155\157\x6f\x79\x6d"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto cmqucgoewuyieoyk; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto gimmuoqwckiseaik; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto iqcogmsguwoikame; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); iqcogmsguwoikame: gimmuoqwckiseaik: cmqucgoewuyieoyk: return $gwykaiwqgaycyggs; } }
