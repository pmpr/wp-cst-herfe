<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587693f468             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\162\x68\x68\163\165\142\x77\160\x63\157\x6f\x6b\151\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\x75\142\163\143\162\x69\x70\x74\151\x6f\x6e\x5f\143\150\145\143\x6b\137\141\143\143\x65\x73\x73\137\x72\x65\163\165\x6c\x74", [$this, "\145\151\157\x67\x6f\x6b\x75\x65\153\163\147\x6d\157\x6f\x79\x6d"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto yuoeumyiuqkuouey; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto eoyiumycaigawmmc; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto mgcuiguaomoqwwwm; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); mgcuiguaomoqwwwm: eoyiumycaigawmmc: yuoeumyiuqkuouey: return $gwykaiwqgaycyggs; } }
