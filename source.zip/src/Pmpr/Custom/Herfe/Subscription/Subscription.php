<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b9b5de1df             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\x72\x68\x68\163\165\x62\x77\x70\x63\157\157\x6b\151\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\x75\x62\163\x63\x72\151\x70\164\x69\x6f\x6e\137\x63\150\x65\143\153\137\x61\x63\143\145\163\x73\137\162\145\x73\165\154\164", [$this, "\145\x69\157\x67\157\x6b\x75\x65\153\163\x67\155\x6f\x6f\171\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto umgaesggesswoaqe; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(self::mswoacegomcucaik)) { goto wwkgkaecgiwggcck; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto kciouyuaqkyqomam; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); kciouyuaqkyqomam: wwkgkaecgiwggcck: umgaesggesswoaqe: return $gwykaiwqgaycyggs; } }
