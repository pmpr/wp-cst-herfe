<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bd2e256d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { }
