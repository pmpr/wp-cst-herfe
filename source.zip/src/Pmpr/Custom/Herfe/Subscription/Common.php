<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { }
