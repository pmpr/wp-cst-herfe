<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Woocommerce; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { }
