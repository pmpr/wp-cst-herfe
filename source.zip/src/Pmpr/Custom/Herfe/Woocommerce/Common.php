<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed3b1eed             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Woocommerce; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { }
