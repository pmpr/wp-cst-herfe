<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Woocommerce; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { }
