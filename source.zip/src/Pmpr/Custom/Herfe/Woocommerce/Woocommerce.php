<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Order::symcgieuakksimmu(); Checkout::symcgieuakksimmu(); } }
