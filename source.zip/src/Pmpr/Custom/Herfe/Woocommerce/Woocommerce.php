<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707dc01428             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Order::symcgieuakksimmu(); Checkout::symcgieuakksimmu(); } }
