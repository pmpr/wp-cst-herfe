<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Order::symcgieuakksimmu(); Checkout::symcgieuakksimmu(); } }
