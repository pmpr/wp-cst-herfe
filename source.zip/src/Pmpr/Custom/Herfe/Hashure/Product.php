<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587693f468             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Hashure; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ObjectTrait; use Pmpr\Custom\Herfe\Setting; class Product extends Common { use ObjectTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\157\x6f\143\x6f\x6d\x6d\145\162\x63\x65\137\x62\145\146\157\x72\x65\137\x73\151\x6e\147\x6c\x65\x5f\x70\162\x6f\x64\x75\143\x74", [$this, "\x67\x69\145\x63\163\167\141\x63\x6b\167\x6d\x77\167\x73\153\171"], 0); } public function giecswackwmwwsky() { global $product; if (!($this->qmoswyyemykyycko($product) && !$this->ysuoseskooqusqua())) { goto smcguieygyqcaqgs; } $uamcoiueqaamsqma = $this->weysguygiseoukqw(Setting::gwmieqaoaqwcawse, ''); if (!$uamcoiueqaamsqma) { goto wmumywgyyeagqoeq; } $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->yiggueaiwiygoiyi($uamcoiueqaamsqma, self::mgowaqweusymwoqu); wmumywgyyeagqoeq: smcguieygyqcaqgs: } }
