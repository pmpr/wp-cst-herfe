<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Hashure; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ObjectTrait; use Pmpr\Custom\Herfe\Setting; class Product extends Common { use ObjectTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\157\157\x63\157\155\155\x65\162\143\x65\137\142\x65\146\x6f\x72\x65\137\163\151\x6e\147\154\x65\x5f\x70\162\157\144\165\143\x74", [$this, "\x67\151\x65\x63\x73\167\x61\x63\x6b\x77\x6d\x77\x77\x73\x6b\171"], 0); } public function giecswackwmwwsky() { global $product; if (!($this->qmoswyyemykyycko($product) && !$this->ysuoseskooqusqua())) { goto amgsueumgaguceaa; } $uamcoiueqaamsqma = $this->weysguygiseoukqw(Setting::gwmieqaoaqwcawse, ''); if (!$uamcoiueqaamsqma) { goto mwysseaekcsiesmm; } $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->yiggueaiwiygoiyi($uamcoiueqaamsqma, self::mgowaqweusymwoqu); mwysseaekcsiesmm: amgsueumgaguceaa: } }
