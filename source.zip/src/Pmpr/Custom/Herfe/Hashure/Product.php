<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Hashure; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ObjectTrait; use Pmpr\Custom\Herfe\Setting; class Product extends Common { use ObjectTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\157\x6f\143\x6f\155\155\145\162\143\x65\137\x62\145\x66\157\162\145\137\163\151\x6e\x67\154\145\137\160\x72\157\144\165\143\164", [$this, "\147\151\145\143\x73\167\x61\x63\153\x77\x6d\167\x77\163\x6b\171"], 0); } public function giecswackwmwwsky() { global $product; if (!($this->qmoswyyemykyycko($product) && !$this->ysuoseskooqusqua())) { goto ikqqskkqqwmwssoo; } $uamcoiueqaamsqma = $this->weysguygiseoukqw(Setting::gwmieqaoaqwcawse, ''); if (!$uamcoiueqaamsqma) { goto iwekmyyccgiyuecc; } $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->yiggueaiwiygoiyi($uamcoiueqaamsqma, self::mgowaqweusymwoqu); iwekmyyccgiyuecc: ikqqskkqqwmwssoo: } }
