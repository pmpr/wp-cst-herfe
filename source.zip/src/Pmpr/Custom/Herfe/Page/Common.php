<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Common extends Page implements CommonInterface { }
