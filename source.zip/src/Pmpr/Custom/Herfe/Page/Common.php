<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Common extends Page implements CommonInterface { }
