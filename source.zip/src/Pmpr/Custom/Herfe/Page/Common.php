<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Common extends Page implements CommonInterface { }
