<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b0f6e10d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Common extends Page implements CommonInterface { }
