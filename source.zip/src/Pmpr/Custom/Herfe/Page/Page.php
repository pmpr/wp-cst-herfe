<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebf66cbec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Custom\Herfe\Container; class Page extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x69\156\x69\164\x5f\144\x65\x76\x65\x6c\x6f\x70\137\160\141\147\x65", "\137\x5f\x72\x65\x74\165\x72\x6e\137\x74\x72\165\x65"); } public function mameiwsayuyquoeq() { Visual::symcgieuakksimmu(); Auditory::symcgieuakksimmu(); VisualAuditory::symcgieuakksimmu(); LatestMagazine::symcgieuakksimmu(); } }
