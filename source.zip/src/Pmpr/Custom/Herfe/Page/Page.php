<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Custom\Herfe\Container; class Page extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\151\x6e\151\164\137\144\x65\166\145\x6c\x6f\160\x5f\x70\x61\x67\x65", "\x5f\137\x72\x65\x74\x75\x72\156\x5f\x74\162\x75\145"); } public function mameiwsayuyquoeq() { Visual::symcgieuakksimmu(); Auditory::symcgieuakksimmu(); VisualAuditory::symcgieuakksimmu(); LatestMagazine::symcgieuakksimmu(); } }
