<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class Visual extends AbstractVisualAuditory { public function __construct() { $this->slug = self::yyigwaqioecwemiw; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\126\151\x73\x75\141\x6c", PR__CST__HERFE); } }
