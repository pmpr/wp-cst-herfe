<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b0f6e10d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class Visual extends AbstractVisualAuditory { public function __construct() { $this->slug = self::yyigwaqioecwemiw; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\126\151\x73\x75\x61\154", PR__CST__HERFE); } }
