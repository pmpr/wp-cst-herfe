<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebf66cbec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Interfaces\Constants; class Visual extends AbstractVisualAuditory { public function __construct() { $this->slug = Constants::yyigwaqioecwemiw; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x56\151\x73\x75\141\x6c", PR__CST__HERFE); } }
