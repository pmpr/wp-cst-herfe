<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce793b2e5ac             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class VisualAuditory extends AbstractVisualAuditory { public function __construct() { $this->slug = self::uuseyckuwmiouskw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\126\151\163\165\x61\x6c\40\x26\x20\101\165\x64\151\x74\157\162\171", PR__CST__HERFE); } }
