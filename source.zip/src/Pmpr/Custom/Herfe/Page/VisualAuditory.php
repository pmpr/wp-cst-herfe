<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707dc01428             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class VisualAuditory extends AbstractVisualAuditory { public function __construct() { $this->slug = self::uuseyckuwmiouskw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\126\x69\x73\x75\141\154\x20\x26\x20\x41\165\144\x69\x74\157\162\x79", PR__CST__HERFE); } }
