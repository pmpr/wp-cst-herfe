<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f0256adc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class VisualAuditory extends AbstractVisualAuditory { public function __construct() { $this->slug = self::uuseyckuwmiouskw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x56\151\x73\165\x61\154\x20\46\x20\101\165\x64\x69\164\x6f\x72\x79", PR__CST__HERFE); } }
