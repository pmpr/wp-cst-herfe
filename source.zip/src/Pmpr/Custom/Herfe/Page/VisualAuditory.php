<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed3b1eed             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class VisualAuditory extends AbstractVisualAuditory { public function __construct() { $this->slug = self::uuseyckuwmiouskw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\126\x69\163\x75\141\x6c\x20\46\40\x41\x75\144\x69\164\157\x72\171", PR__CST__HERFE); } }
