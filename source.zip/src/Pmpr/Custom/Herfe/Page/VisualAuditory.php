<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebf66cbec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class VisualAuditory extends AbstractVisualAuditory { public function __construct() { $this->slug = self::uuseyckuwmiouskw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x56\x69\163\165\141\x6c\40\46\x20\x41\165\144\151\164\x6f\162\x79", PR__CST__HERFE); } }
