<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class Auditory extends AbstractVisualAuditory { public function __construct() { $this->slug = self::gcwcqmwwgiqsaame; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\165\x64\x69\x74\157\162\171", PR__CST__HERFE); } }
