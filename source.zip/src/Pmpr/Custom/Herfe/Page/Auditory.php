<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class Auditory extends AbstractVisualAuditory { public function __construct() { $this->slug = self::gcwcqmwwgiqsaame; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\x75\x64\x69\x74\157\x72\171", PR__CST__HERFE); } }
