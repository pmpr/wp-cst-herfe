<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a5d85e80d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\141\164\145\x73\164\x2d\155\x61\147\x61\x7a\x69\156\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\x61\x74\145\x73\x74\x20\115\x61\x67\141\172\x69\156\145", PR__CST__HERFE); } }
