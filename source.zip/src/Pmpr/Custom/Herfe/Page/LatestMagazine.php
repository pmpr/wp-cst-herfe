<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\141\x74\145\163\x74\x2d\155\141\x67\x61\172\x69\x6e\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\141\x74\145\x73\x74\40\x4d\x61\147\141\172\151\156\x65", PR__CST__HERFE); } }
