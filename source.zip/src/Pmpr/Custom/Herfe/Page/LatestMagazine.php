<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b39011a0f98             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Herfe\Setting; class LatestMagazine extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x6c\141\164\145\x73\164\55\155\141\147\141\172\151\156\x65")->gswweykyogmsyawy(__("\114\x61\164\145\163\164\40\x4d\x61\147\x61\x7a\x69\x6e\145", PR__CST__HERFE))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::ouosmmwowoocgiei)); } }
