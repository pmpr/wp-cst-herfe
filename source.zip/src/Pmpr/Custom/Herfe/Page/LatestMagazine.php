<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c4dccd5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Herfe\Setting; class LatestMagazine extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\154\141\164\145\x73\164\55\x6d\x61\x67\141\x7a\x69\x6e\145")->gswweykyogmsyawy(__("\x4c\141\x74\145\x73\164\x20\115\141\x67\x61\x7a\x69\x6e\x65", PR__CST__HERFE))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::ouosmmwowoocgiei)); } }
