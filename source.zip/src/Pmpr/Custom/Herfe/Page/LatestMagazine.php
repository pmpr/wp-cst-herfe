<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed3b1eed             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\164\x65\x73\x74\x2d\x6d\141\x67\141\172\151\156\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\141\164\145\163\164\x20\x4d\x61\x67\x61\172\151\156\145", PR__CST__HERFE); } }
