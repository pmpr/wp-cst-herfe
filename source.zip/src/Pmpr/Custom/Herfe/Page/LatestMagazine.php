<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\x61\x74\145\163\164\x2d\x6d\x61\147\141\x7a\x69\156\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\x61\x74\x65\163\x74\40\115\141\x67\x61\x7a\x69\x6e\x65", PR__CST__HERFE); } }
