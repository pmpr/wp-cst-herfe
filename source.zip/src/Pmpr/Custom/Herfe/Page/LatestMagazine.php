<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce711c12d1c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\141\x74\x65\x73\164\55\155\x61\147\141\x7a\151\x6e\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\141\164\x65\163\x74\40\115\141\147\141\172\151\x6e\145", PR__CST__HERFE); } }
