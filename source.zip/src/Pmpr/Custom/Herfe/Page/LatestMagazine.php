<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707dc01428             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\x61\x74\x65\163\x74\55\155\x61\147\x61\x7a\151\156\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\141\x74\145\163\x74\x20\x4d\x61\x67\141\172\x69\x6e\x65", PR__CST__HERFE); } }
