<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce115ac0a49             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\x61\164\145\x73\x74\55\x6d\x61\x67\141\172\151\156\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\x61\x74\x65\x73\x74\40\115\x61\147\x61\x7a\151\x6e\x65", PR__CST__HERFE); } }
