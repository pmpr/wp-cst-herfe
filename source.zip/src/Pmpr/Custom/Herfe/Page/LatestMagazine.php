<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8972a818             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\164\145\163\x74\55\155\x61\x67\141\172\x69\156\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\x61\164\145\163\164\40\115\x61\x67\x61\x7a\151\x6e\145", PR__CST__HERFE); } }
