<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebf66cbec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\x74\x65\x73\x74\x2d\155\x61\147\x61\172\x69\x6e\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\141\x74\145\163\164\x20\x4d\141\147\x61\172\x69\156\145", PR__CST__HERFE); } }
