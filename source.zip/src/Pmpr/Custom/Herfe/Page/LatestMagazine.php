<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\x74\x65\163\164\55\x6d\141\x67\141\x7a\151\x6e\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\x61\x74\145\x73\164\x20\x4d\x61\147\141\172\151\x6e\145", PR__CST__HERFE); } }
