<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce793b2e5ac             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\x74\145\x73\164\55\155\x61\x67\x61\x7a\x69\156\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\x61\x74\145\x73\164\x20\x4d\x61\147\x61\172\x69\156\145", PR__CST__HERFE); } }
