<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92f25ffc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\141\x74\145\x73\x74\x2d\x6d\x61\x67\x61\x7a\x69\x6e\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\141\164\145\x73\x74\40\x4d\x61\x67\141\172\151\156\x65", PR__CST__HERFE); } }
