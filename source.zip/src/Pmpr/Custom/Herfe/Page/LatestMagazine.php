<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14fbc47f5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\x6c\x61\164\145\163\x74\55\x6d\141\x67\x61\x7a\x69\156\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\141\164\x65\x73\x74\x20\115\141\x67\x61\172\151\x6e\x65", PR__CST__HERFE); } }
