<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ae14587c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; class LatestMagazine extends Page { public function __construct() { $this->slug = "\x6c\x61\164\145\x73\x74\x2d\x6d\141\147\x61\172\x69\x6e\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\141\x74\x65\x73\164\40\115\x61\147\141\x7a\151\156\x65", PR__CST__HERFE); } }
