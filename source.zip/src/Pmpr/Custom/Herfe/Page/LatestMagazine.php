<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bac701c5e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\x74\x65\x73\164\55\155\141\x67\141\172\151\156\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\x61\164\145\x73\164\40\x4d\141\147\141\172\x69\x6e\145", PR__CST__HERFE); } }
