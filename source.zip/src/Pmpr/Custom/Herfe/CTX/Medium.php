<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e04ac0261             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\CTX; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\145\144\151\165\x6d\163", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\144\151\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\144\151\165\155\x20\146\x6f\162\40\155\141\147\141\172\151\x6e\x65\163", PR__CST__HERFE)); } }
