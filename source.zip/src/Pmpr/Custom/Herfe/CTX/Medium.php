<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce115ac0a49             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\144\151\x75\155\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\x65\144\151\x75\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\144\x69\165\x6d\40\x66\x6f\162\x20\x6d\x61\x67\141\x7a\x69\156\x65\x73", PR__CST__HERFE)); } }
