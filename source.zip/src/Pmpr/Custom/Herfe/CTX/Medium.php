<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\144\x69\x75\x6d\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\x64\151\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\x65\x64\x69\165\155\x20\146\157\x72\x20\155\x61\147\141\172\151\156\x65\x73", PR__CST__HERFE)); } }
