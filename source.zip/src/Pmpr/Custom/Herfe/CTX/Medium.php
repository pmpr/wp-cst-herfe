<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\145\144\x69\x75\x6d\163", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\144\151\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\145\x64\x69\x75\155\40\x66\x6f\x72\x20\155\141\x67\x61\172\x69\x6e\x65\163", PR__CST__HERFE)); } }
