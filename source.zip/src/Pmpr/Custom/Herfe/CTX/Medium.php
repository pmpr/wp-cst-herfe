<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\145\144\x69\165\155\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\x65\x64\151\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\145\x64\x69\x75\155\x20\146\x6f\162\40\155\x61\147\141\x7a\x69\x6e\145\x73", PR__CST__HERFE)); } }
