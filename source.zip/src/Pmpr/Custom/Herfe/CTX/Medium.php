<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\x65\x64\x69\165\155\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\x65\144\151\165\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\x64\x69\165\155\40\x66\157\162\x20\155\x61\x67\x61\172\151\x6e\145\x73", PR__CST__HERFE)); } }
