<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd820af53             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\CTX; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\x75\155\163", PR__CST__HERFE))->guiaswksukmgageq(__("\115\x65\x64\x69\165\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\x64\x69\165\x6d\x20\146\157\162\40\155\x61\147\141\x7a\x69\x6e\145\163", PR__CST__HERFE)); } }
