<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b57409bfc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\x65\144\151\165\155\163", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\x64\151\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\x64\x69\x75\x6d\x20\x66\157\x72\40\155\141\x67\141\x7a\151\156\x65\163", PR__CST__HERFE)); } }
