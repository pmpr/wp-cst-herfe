<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f0256adc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\x65\144\x69\x75\x6d\163", PR__CST__HERFE))->guiaswksukmgageq(__("\115\x65\x64\x69\165\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\145\144\151\165\155\x20\x66\x6f\x72\x20\155\141\x67\141\x7a\151\x6e\x65\x73", PR__CST__HERFE)); } }
