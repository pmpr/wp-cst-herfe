<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8972a818             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\x75\x6d\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\145\x64\x69\165\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\x65\144\151\165\155\x20\x66\x6f\x72\40\x6d\x61\x67\141\172\x69\156\145\163", PR__CST__HERFE)); } }
