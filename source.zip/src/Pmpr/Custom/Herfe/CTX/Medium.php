<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587693f468             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\x65\144\151\165\155\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\x65\x64\x69\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\x65\144\151\x75\155\x20\x66\157\x72\40\155\x61\147\141\172\x69\x6e\145\x73", PR__CST__HERFE)); } }
