<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707dc01428             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\145\x64\151\x75\x6d\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\x64\x69\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\x64\x69\x75\x6d\40\146\x6f\x72\x20\x6d\141\x67\141\x7a\151\156\145\x73", PR__CST__HERFE)); } }
