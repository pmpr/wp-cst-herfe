<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\145\144\x69\x75\x6d\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\145\144\x69\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\x65\144\151\x75\x6d\x20\146\x6f\x72\x20\x6d\141\x67\x61\x7a\x69\x6e\145\x73", PR__CST__HERFE)); } }
