<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14fbc47f5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\x64\151\x75\x6d\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\x64\151\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\x65\144\151\165\x6d\40\x66\x6f\x72\x20\155\141\147\141\172\x69\x6e\x65\x73", PR__CST__HERFE)); } }
