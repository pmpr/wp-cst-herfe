<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebf66cbec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\145\144\x69\x75\155\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\x64\x69\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\145\144\x69\x75\x6d\x20\146\157\162\40\155\141\x67\141\172\151\156\x65\163", PR__CST__HERFE)); } }
