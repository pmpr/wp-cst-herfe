<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d24ec0e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\x65\144\151\x75\x6d\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\144\x69\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\x65\x64\x69\x75\155\40\146\157\x72\x20\x6d\141\x67\141\x7a\x69\x6e\x65\x73", PR__CST__HERFE)); } }
