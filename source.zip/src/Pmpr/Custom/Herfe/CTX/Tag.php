<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\164", [$this, "\145\161\145\143\x63\167\x63\157\x75\151\151\153\145\151\171\x61"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\164\141\147\137\151\x6d\141\x67\145")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\x70\x6f\163\164\137\164\x61\147\x5f\x74\150\x75\155\x62\156\141\x69\x6c")->gswweykyogmsyawy(__("\x49\155\141\x67\145", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(self::ocsomysosuqaimuc)->register(); } }
