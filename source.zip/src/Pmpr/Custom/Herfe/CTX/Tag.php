<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\x74", [$this, "\145\x71\x65\143\x63\167\143\157\165\151\151\153\x65\151\171\141"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\x74\x61\147\137\151\155\x61\x67\x65")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\x70\157\x73\x74\x5f\x74\141\x67\137\164\x68\165\x6d\142\156\x61\x69\154")->gswweykyogmsyawy(__("\x49\155\x61\x67\145", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(self::ocsomysosuqaimuc)->register(); } }
