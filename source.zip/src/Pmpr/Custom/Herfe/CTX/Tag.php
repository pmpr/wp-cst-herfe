<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8972a818             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\x74", [$this, "\145\161\x65\143\x63\x77\143\x6f\x75\151\x69\153\x65\x69\x79\141"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\164\x61\x67\x5f\151\x6d\141\147\145")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\x70\x6f\x73\164\137\164\141\147\x5f\164\x68\165\x6d\142\x6e\141\x69\154")->gswweykyogmsyawy(__("\x49\x6d\x61\147\x65", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(Constants::ocsomysosuqaimuc)->register(); } }
