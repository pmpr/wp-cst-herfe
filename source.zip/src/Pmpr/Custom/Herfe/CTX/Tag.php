<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a5d85e80d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\x74", [$this, "\x65\x71\x65\x63\143\x77\x63\157\165\151\151\x6b\x65\151\171\141"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\x74\x61\147\x5f\151\x6d\141\147\145")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\160\157\163\164\137\x74\141\147\x5f\x74\150\165\155\142\156\x61\151\154")->gswweykyogmsyawy(__("\111\155\141\x67\x65", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(self::ocsomysosuqaimuc)->register(); } }
