<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce793b2e5ac             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\x74", [$this, "\145\x71\145\x63\143\x77\143\x6f\165\151\151\153\145\x69\171\x61"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\x74\141\147\137\x69\155\141\x67\145")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\x70\x6f\x73\x74\137\x74\141\147\137\164\150\x75\x6d\x62\156\141\151\154")->gswweykyogmsyawy(__("\111\155\x61\147\x65", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(Constants::ocsomysosuqaimuc)->register(); } }
