<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Common extends CTX implements CommonInterface { }
