<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Common extends CTX implements CommonInterface { }
