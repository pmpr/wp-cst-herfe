<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587693f468             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Common extends CTX implements CommonInterface { }
