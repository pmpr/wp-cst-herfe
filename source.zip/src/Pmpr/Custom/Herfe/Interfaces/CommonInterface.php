<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed3b1eed             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\145\x67\x69\163\164\145\162\145\x64\137\157\156\x5f\x68\x61\163\x68\x75\162\x65"; const uiiqamagukacsssy = "\x63\163\x74\137\x68\145\162\146\x65\150\137"; const yyigwaqioecwemiw = "\x76\x69\x73\165\x61\154"; const MEDIUM = "\155\145\x64\151\x75\x6d"; const gcwcqmwwgiqsaame = "\x61\165\x64\x69\164\157\x72\x79"; const wsuusqigsoomsyky = "\x6d\x61\x67\141\x7a\x69\156\x65"; const seyosiicaqsgmuwa = "\145\x6e\x67\154\x69\163\150\x5f\141\162\164\x69\143\x6c\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\x72\x74\151\x63\154\145\137\x63\x61\x74\x65\x67\x6f\162\171"; const aqmqeywcmyguggoo = "\x65\x76\x65\x6e\164"; const gicwoyoeuwosyuau = "\x67\141\x6c\154\145\162\x79"; const cqkewmmoacqamyce = "\x61\144\166\145\162\x74\x69\x73\x65"; const kueeagiqseeaeogs = "\x61\144\166\x65\162\x74\x69\x73\145\x72"; const qsoqogygekgcqgmw = "\x6f\x72\x67\141\x6e\x69\x7a\x65\x5f\x61\x64\x76\x65\x72\x74\x69\x73\x65"; }
