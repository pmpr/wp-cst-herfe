<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587693f468             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const yyigwaqioecwemiw = "\166\151\163\165\x61\154"; const MEDIUM = "\155\145\144\x69\x75\155"; const gcwcqmwwgiqsaame = "\x61\165\144\151\164\157\162\171"; const wsuusqigsoomsyky = "\x6d\x61\147\141\172\151\x6e\x65"; const seyosiicaqsgmuwa = "\x65\x6e\x67\x6c\151\163\150\137\141\x72\x74\x69\x63\154\x65"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\x72\164\151\x63\154\x65\137\x63\141\x74\x65\x67\157\x72\x79"; const aqmqeywcmyguggoo = "\145\x76\145\x6e\x74"; const gicwoyoeuwosyuau = "\147\x61\x6c\154\145\162\171"; const cqkewmmoacqamyce = "\x61\144\x76\x65\x72\164\151\163\x65"; const kueeagiqseeaeogs = "\141\x64\x76\145\x72\164\151\x73\145\162"; const qsoqogygekgcqgmw = "\x6f\162\x67\x61\156\x69\x7a\145\137\x61\x64\166\x65\162\x74\x69\163\145"; }
