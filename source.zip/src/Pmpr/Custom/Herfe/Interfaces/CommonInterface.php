<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const yyigwaqioecwemiw = "\166\x69\163\165\x61\154"; const MEDIUM = "\155\145\144\x69\165\155"; const gcwcqmwwgiqsaame = "\141\165\x64\151\x74\x6f\x72\171"; const wsuusqigsoomsyky = "\155\141\147\x61\172\x69\156\x65"; const seyosiicaqsgmuwa = "\145\x6e\x67\154\151\163\x68\137\x61\162\164\x69\143\154\x65"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\x72\164\151\x63\x6c\x65\137\143\x61\x74\x65\147\x6f\x72\171"; const aqmqeywcmyguggoo = "\145\166\x65\156\164"; const gicwoyoeuwosyuau = "\147\141\x6c\x6c\x65\x72\171"; const cqkewmmoacqamyce = "\x61\x64\x76\145\162\164\x69\x73\145"; const kueeagiqseeaeogs = "\x61\144\x76\145\162\x74\x69\x73\x65\162"; const qsoqogygekgcqgmw = "\157\x72\x67\141\x6e\x69\172\x65\137\141\144\166\x65\162\x74\151\x73\x65"; }
