<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b9b5de1df             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\x65\x67\x69\163\x74\145\x72\x65\144\137\157\156\x5f\150\x61\163\150\165\x72\x65"; const uiiqamagukacsssy = "\x63\163\x74\x5f\x68\x65\162\146\x65\x68\x5f"; const yyigwaqioecwemiw = "\x76\151\163\165\x61\154"; const MEDIUM = "\x6d\x65\144\151\x75\x6d"; const gcwcqmwwgiqsaame = "\x61\x75\144\151\164\157\x72\171"; const wsuusqigsoomsyky = "\x6d\x61\x67\x61\x7a\151\x6e\145"; const seyosiicaqsgmuwa = "\145\156\x67\154\x69\x73\150\137\141\x72\164\151\143\x6c\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\x72\x74\x69\x63\154\x65\x5f\x63\141\164\145\147\x6f\x72\x79"; const aqmqeywcmyguggoo = "\145\166\145\156\x74"; const gicwoyoeuwosyuau = "\x67\141\x6c\154\x65\162\171"; const cqkewmmoacqamyce = "\x61\144\166\x65\x72\x74\151\163\145"; const kueeagiqseeaeogs = "\x61\x64\166\x65\x72\x74\x69\x73\145\x72"; const qsoqogygekgcqgmw = "\157\x72\147\x61\156\151\172\x65\137\141\144\x76\x65\162\x74\x69\163\145"; }
