<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b57409bfc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\x72\145\x67\x69\163\x74\145\x72\145\x64\137\x6f\156\137\x68\x61\x73\x68\165\x72\x65"; const uiiqamagukacsssy = "\143\x73\x74\137\x68\x65\x72\x66\x65\150\x5f"; const yyigwaqioecwemiw = "\166\x69\x73\x75\141\x6c"; const MEDIUM = "\155\145\144\151\x75\155"; const gcwcqmwwgiqsaame = "\x61\165\144\x69\x74\x6f\162\x79"; const wsuusqigsoomsyky = "\155\x61\x67\141\172\151\156\x65"; const seyosiicaqsgmuwa = "\x65\x6e\x67\154\x69\163\150\x5f\x61\x72\164\x69\x63\154\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\162\164\x69\x63\154\x65\137\x63\141\164\145\147\x6f\162\x79"; const aqmqeywcmyguggoo = "\x65\166\x65\x6e\x74"; const gicwoyoeuwosyuau = "\147\141\154\x6c\145\x72\171"; const cqkewmmoacqamyce = "\x61\144\166\x65\x72\164\151\x73\145"; const kueeagiqseeaeogs = "\141\x64\x76\145\162\164\x69\163\145\x72"; const qsoqogygekgcqgmw = "\x6f\x72\x67\141\x6e\x69\172\x65\x5f\141\x64\x76\x65\x72\164\151\163\145"; }
