<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bac701c5e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\x65\147\x69\163\164\x65\x72\145\x64\137\x6f\156\x5f\x68\x61\x73\x68\x75\x72\145"; const uiiqamagukacsssy = "\143\163\x74\x5f\150\x65\162\146\x65\x68\137"; const yyigwaqioecwemiw = "\x76\x69\x73\165\x61\x6c"; const MEDIUM = "\x6d\x65\144\151\x75\x6d"; const gcwcqmwwgiqsaame = "\141\165\x64\151\x74\x6f\162\x79"; const wsuusqigsoomsyky = "\x6d\x61\147\141\172\151\156\x65"; const seyosiicaqsgmuwa = "\145\x6e\147\154\x69\x73\150\137\x61\x72\164\151\x63\x6c\x65"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\162\x74\x69\143\x6c\x65\137\x63\141\x74\x65\x67\x6f\x72\171"; const aqmqeywcmyguggoo = "\x65\x76\145\156\x74"; const gicwoyoeuwosyuau = "\147\x61\x6c\x6c\145\162\x79"; const cqkewmmoacqamyce = "\141\144\x76\x65\162\x74\x69\x73\145"; const kueeagiqseeaeogs = "\x61\x64\x76\x65\162\164\151\163\x65\x72"; const qsoqogygekgcqgmw = "\157\x72\147\141\156\151\x7a\x65\x5f\141\x64\x76\x65\x72\164\x69\163\145"; }
