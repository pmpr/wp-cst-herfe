<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d24ec0e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\x72\x65\x67\x69\x73\x74\x65\x72\145\144\x5f\x6f\x6e\137\150\141\163\x68\165\x72\145"; const uiiqamagukacsssy = "\x63\163\164\x5f\150\145\162\146\x65\150\137"; const yyigwaqioecwemiw = "\166\x69\163\x75\x61\154"; const MEDIUM = "\x6d\x65\144\151\x75\x6d"; const gcwcqmwwgiqsaame = "\x61\x75\x64\151\x74\x6f\x72\171"; const wsuusqigsoomsyky = "\x6d\x61\147\141\172\x69\156\145"; const seyosiicaqsgmuwa = "\x65\156\x67\x6c\x69\163\150\137\141\162\164\151\143\154\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\x72\x74\151\x63\x6c\145\x5f\x63\x61\164\145\147\157\162\171"; const aqmqeywcmyguggoo = "\145\x76\145\156\164"; const cqkewmmoacqamyce = "\141\144\x76\x65\x72\164\x69\x73\x65"; const kueeagiqseeaeogs = "\141\144\166\145\162\x74\x69\x73\x65\162"; const qsoqogygekgcqgmw = "\157\162\x67\141\156\x69\172\145\137\141\144\166\145\162\x74\151\163\145"; }
