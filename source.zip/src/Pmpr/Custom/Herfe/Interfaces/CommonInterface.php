<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\x65\x67\151\163\x74\145\162\145\x64\137\x6f\x6e\x5f\x68\x61\x73\150\x75\x72\x65"; const uiiqamagukacsssy = "\x63\x73\164\137\x68\x65\162\146\145\150\x5f"; const yyigwaqioecwemiw = "\166\151\163\x75\x61\x6c"; const MEDIUM = "\155\145\x64\151\165\155"; const gcwcqmwwgiqsaame = "\x61\x75\144\151\164\x6f\x72\171"; const wsuusqigsoomsyky = "\x6d\141\x67\141\172\151\x6e\x65"; const seyosiicaqsgmuwa = "\145\156\x67\154\151\163\x68\x5f\141\162\164\151\143\154\x65"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\x72\x74\151\143\154\145\137\x63\141\x74\x65\147\x6f\162\x79"; const aqmqeywcmyguggoo = "\145\x76\145\x6e\x74"; const cqkewmmoacqamyce = "\x61\144\166\145\x72\x74\x69\163\x65"; const kueeagiqseeaeogs = "\x61\x64\166\x65\x72\164\x69\163\x65\162"; const qsoqogygekgcqgmw = "\x6f\x72\x67\141\156\x69\172\x65\137\x61\x64\x76\x65\x72\x74\151\163\145"; }
