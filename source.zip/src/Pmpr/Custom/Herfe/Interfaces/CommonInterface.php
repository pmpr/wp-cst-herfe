<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a5d85e80d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\x72\x65\147\151\163\164\145\162\x65\x64\x5f\157\x6e\x5f\150\x61\163\150\165\162\145"; const uiiqamagukacsssy = "\x63\163\x74\137\150\x65\x72\146\145\x68\137"; const yyigwaqioecwemiw = "\x76\x69\x73\x75\x61\x6c"; const MEDIUM = "\155\145\144\151\x75\x6d"; const gcwcqmwwgiqsaame = "\x61\x75\x64\151\x74\x6f\162\x79"; const wsuusqigsoomsyky = "\x6d\141\x67\x61\172\x69\x6e\x65"; const seyosiicaqsgmuwa = "\x65\x6e\x67\154\x69\x73\150\x5f\141\x72\164\151\x63\154\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\x72\x74\x69\143\x6c\x65\x5f\x63\141\x74\x65\147\x6f\162\171"; const aqmqeywcmyguggoo = "\x65\166\145\x6e\164"; const gicwoyoeuwosyuau = "\x67\x61\x6c\x6c\x65\x72\x79"; const cqkewmmoacqamyce = "\x61\x64\166\x65\x72\x74\x69\x73\x65"; const kueeagiqseeaeogs = "\x61\x64\166\x65\162\164\x69\x73\145\x72"; const qsoqogygekgcqgmw = "\x6f\162\147\141\156\151\172\145\137\x61\x64\166\x65\162\164\151\x73\145"; }
