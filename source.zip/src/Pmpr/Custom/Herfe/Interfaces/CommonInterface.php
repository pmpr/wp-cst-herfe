<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f0256adc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\x65\147\151\163\164\x65\x72\x65\144\137\157\156\137\150\141\163\x68\x75\x72\145"; const uiiqamagukacsssy = "\x63\163\164\x5f\x68\145\162\146\x65\x68\x5f"; const yyigwaqioecwemiw = "\x76\x69\163\x75\141\154"; const MEDIUM = "\155\x65\x64\x69\x75\x6d"; const gcwcqmwwgiqsaame = "\x61\x75\144\151\x74\157\162\x79"; const wsuusqigsoomsyky = "\x6d\141\x67\x61\172\x69\156\145"; const seyosiicaqsgmuwa = "\x65\x6e\147\x6c\151\x73\150\137\141\162\164\x69\x63\x6c\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\162\164\151\143\x6c\x65\137\143\141\x74\145\147\157\x72\171"; const aqmqeywcmyguggoo = "\x65\166\x65\156\164"; const cqkewmmoacqamyce = "\x61\144\x76\x65\x72\x74\151\x73\x65"; const kueeagiqseeaeogs = "\141\x64\x76\x65\162\x74\151\x73\x65\x72"; const qsoqogygekgcqgmw = "\157\162\x67\x61\156\x69\172\x65\137\x61\144\x76\145\x72\164\151\163\x65"; }
