<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\145\x67\x69\163\x74\145\x72\145\144\137\x6f\x6e\137\150\141\x73\x68\165\162\x65"; const uiiqamagukacsssy = "\143\163\164\x5f\x68\x65\x72\x66\145\x68\137"; const yyigwaqioecwemiw = "\166\151\x73\165\x61\x6c"; const MEDIUM = "\x6d\145\x64\151\165\x6d"; const gcwcqmwwgiqsaame = "\141\165\x64\151\164\x6f\162\171"; const wsuusqigsoomsyky = "\155\141\x67\x61\172\151\156\x65"; const seyosiicaqsgmuwa = "\145\156\x67\x6c\151\163\x68\137\141\x72\x74\x69\x63\154\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\x72\164\x69\143\x6c\145\x5f\143\141\x74\145\147\x6f\x72\x79"; const aqmqeywcmyguggoo = "\145\x76\145\x6e\164"; const cqkewmmoacqamyce = "\141\144\x76\x65\162\164\x69\163\x65"; const kueeagiqseeaeogs = "\x61\x64\x76\145\162\164\x69\163\145\x72"; const qsoqogygekgcqgmw = "\x6f\x72\x67\141\x6e\x69\172\x65\x5f\141\144\x76\145\x72\164\x69\x73\145"; }
