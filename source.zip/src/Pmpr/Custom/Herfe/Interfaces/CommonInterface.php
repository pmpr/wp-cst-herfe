<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e5372b91             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\x72\145\147\151\163\x74\145\x72\x65\144\x5f\157\156\137\x68\141\163\x68\165\162\145"; const uiiqamagukacsssy = "\x63\163\164\x5f\150\145\162\146\x65\150\137"; const yyigwaqioecwemiw = "\x76\151\x73\x75\x61\x6c"; const MEDIUM = "\155\145\144\151\165\155"; const gcwcqmwwgiqsaame = "\x61\x75\x64\151\164\157\x72\171"; const wsuusqigsoomsyky = "\x6d\141\147\141\x7a\x69\156\x65"; const seyosiicaqsgmuwa = "\x65\x6e\147\x6c\x69\x73\x68\137\141\x72\x74\x69\x63\154\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\x72\164\x69\143\154\145\x5f\143\141\x74\145\x67\x6f\162\x79"; const aqmqeywcmyguggoo = "\145\x76\x65\x6e\164"; const cqkewmmoacqamyce = "\x61\144\x76\x65\162\x74\151\x73\x65"; const kueeagiqseeaeogs = "\141\144\166\145\162\164\151\x73\x65\x72"; const qsoqogygekgcqgmw = "\157\x72\x67\141\x6e\x69\x7a\x65\137\x61\144\166\145\162\164\151\x73\x65"; }
