<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const yyigwaqioecwemiw = "\166\151\163\x75\141\154"; const MEDIUM = "\x6d\145\x64\x69\x75\x6d"; const gcwcqmwwgiqsaame = "\x61\x75\x64\151\x74\x6f\162\171"; const wsuusqigsoomsyky = "\155\x61\147\x61\x7a\151\x6e\x65"; const seyosiicaqsgmuwa = "\x65\156\147\154\x69\x73\150\x5f\x61\162\x74\x69\x63\x6c\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\162\164\x69\143\x6c\145\137\143\141\164\x65\x67\157\x72\x79"; const aqmqeywcmyguggoo = "\145\x76\x65\x6e\164"; const gicwoyoeuwosyuau = "\x67\141\x6c\154\x65\162\x79"; const cqkewmmoacqamyce = "\x61\x64\x76\x65\162\164\x69\x73\145"; const kueeagiqseeaeogs = "\x61\144\x76\x65\162\x74\x69\x73\145\162"; const qsoqogygekgcqgmw = "\157\x72\147\141\x6e\x69\172\x65\137\141\x64\x76\x65\x72\164\x69\x73\145"; }
