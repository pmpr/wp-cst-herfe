<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707dc01428             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\x72\x65\x67\x69\163\164\x65\162\x65\x64\137\x6f\156\x5f\150\x61\x73\x68\165\x72\x65"; const uiiqamagukacsssy = "\143\163\164\x5f\x68\x65\162\x66\145\x68\x5f"; const yyigwaqioecwemiw = "\x76\x69\163\165\x61\x6c"; const MEDIUM = "\155\x65\144\x69\165\155"; const gcwcqmwwgiqsaame = "\x61\165\x64\151\x74\157\x72\x79"; const wsuusqigsoomsyky = "\155\x61\147\x61\172\x69\x6e\x65"; const seyosiicaqsgmuwa = "\x65\156\147\x6c\x69\x73\150\x5f\141\x72\x74\x69\x63\154\x65"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\x72\164\x69\x63\x6c\145\x5f\143\x61\164\x65\x67\157\162\171"; const aqmqeywcmyguggoo = "\145\x76\x65\156\164"; const cqkewmmoacqamyce = "\141\144\166\145\162\x74\x69\x73\x65"; const kueeagiqseeaeogs = "\x61\x64\166\x65\162\164\x69\x73\x65\x72"; const qsoqogygekgcqgmw = "\x6f\x72\147\x61\156\151\172\x65\137\141\144\x76\x65\x72\164\151\163\x65"; }
