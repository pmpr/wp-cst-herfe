<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bd2e256d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\145\x67\151\x73\x74\x65\x72\145\144\x5f\x6f\x6e\137\150\141\163\150\x75\162\x65"; const uiiqamagukacsssy = "\x63\163\164\137\x68\145\x72\146\145\x68\137"; const yyigwaqioecwemiw = "\x76\x69\x73\165\141\154"; const MEDIUM = "\x6d\145\144\x69\165\x6d"; const gcwcqmwwgiqsaame = "\141\x75\x64\151\x74\157\162\x79"; const wsuusqigsoomsyky = "\155\141\147\141\172\151\x6e\145"; const seyosiicaqsgmuwa = "\145\156\147\154\151\163\150\x5f\x61\x72\164\x69\143\x6c\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\162\164\151\x63\154\145\x5f\x63\141\x74\145\x67\157\x72\x79"; const aqmqeywcmyguggoo = "\x65\x76\145\x6e\164"; const gicwoyoeuwosyuau = "\x67\141\x6c\154\x65\x72\171"; const cqkewmmoacqamyce = "\141\144\x76\x65\162\164\151\x73\145"; const kueeagiqseeaeogs = "\x61\x64\x76\145\x72\x74\x69\x73\145\x72"; const qsoqogygekgcqgmw = "\x6f\x72\147\141\x6e\x69\x7a\x65\137\141\144\x76\x65\x72\x74\151\163\x65"; }
