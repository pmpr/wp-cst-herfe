<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\145\x67\x69\x73\x74\x65\x72\x65\144\x5f\x6f\156\x5f\150\141\x73\150\165\162\145"; const uiiqamagukacsssy = "\143\x73\164\x5f\x68\145\162\x66\145\150\137"; const yyigwaqioecwemiw = "\166\151\163\165\x61\154"; const MEDIUM = "\x6d\145\144\x69\165\x6d"; const gcwcqmwwgiqsaame = "\x61\165\x64\x69\164\157\162\x79"; const wsuusqigsoomsyky = "\x6d\x61\147\x61\x7a\x69\x6e\145"; const seyosiicaqsgmuwa = "\145\156\147\x6c\x69\163\x68\137\x61\x72\164\151\x63\154\x65"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\x72\x74\x69\143\154\145\137\143\x61\x74\145\x67\157\x72\171"; const aqmqeywcmyguggoo = "\145\166\x65\156\x74"; const cqkewmmoacqamyce = "\x61\144\166\x65\162\164\151\x73\145"; const kueeagiqseeaeogs = "\141\144\166\x65\x72\x74\x69\163\x65\162"; const qsoqogygekgcqgmw = "\157\162\x67\141\x6e\x69\x7a\x65\137\141\144\x76\145\x72\164\x69\163\x65"; }
