<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b0f6e10d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\x72\x65\x67\x69\x73\164\145\162\x65\x64\x5f\157\x6e\x5f\x68\x61\x73\150\x75\162\145"; const uiiqamagukacsssy = "\143\163\164\137\150\145\162\x66\145\150\x5f"; const yyigwaqioecwemiw = "\x76\x69\163\165\141\154"; const MEDIUM = "\x6d\x65\144\x69\x75\x6d"; const gcwcqmwwgiqsaame = "\141\165\144\151\164\157\x72\x79"; const wsuusqigsoomsyky = "\155\x61\x67\141\x7a\151\156\145"; const seyosiicaqsgmuwa = "\x65\x6e\147\x6c\x69\163\x68\x5f\141\162\x74\x69\x63\x6c\x65"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\x61\x72\164\x69\x63\154\x65\x5f\143\x61\164\x65\x67\x6f\162\x79"; const aqmqeywcmyguggoo = "\145\166\x65\x6e\x74"; const gicwoyoeuwosyuau = "\147\141\154\x6c\x65\x72\x79"; const cqkewmmoacqamyce = "\141\144\166\x65\162\x74\151\x73\145"; const kueeagiqseeaeogs = "\141\x64\166\x65\162\164\151\163\145\162"; const qsoqogygekgcqgmw = "\157\x72\147\x61\x6e\151\x7a\x65\137\141\x64\166\145\162\x74\151\163\145"; }
