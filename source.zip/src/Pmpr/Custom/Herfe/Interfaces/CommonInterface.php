<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92f25ffc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\x72\x65\x67\x69\x73\x74\x65\162\145\144\x5f\x6f\x6e\137\150\x61\163\150\165\x72\145"; const uiiqamagukacsssy = "\143\x73\x74\x5f\x68\x65\162\146\145\x68\x5f"; const yyigwaqioecwemiw = "\166\x69\163\165\141\x6c"; const MEDIUM = "\x6d\x65\x64\151\165\x6d"; const gcwcqmwwgiqsaame = "\x61\165\144\151\x74\x6f\x72\171"; const wsuusqigsoomsyky = "\x6d\x61\147\141\x7a\151\x6e\x65"; const seyosiicaqsgmuwa = "\145\x6e\x67\x6c\151\x73\150\137\141\162\164\x69\143\x6c\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\55" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\162\164\151\x63\154\145\137\143\141\x74\x65\x67\157\162\171"; const aqmqeywcmyguggoo = "\145\166\x65\156\164"; const cqkewmmoacqamyce = "\141\144\166\145\162\x74\151\163\145"; const kueeagiqseeaeogs = "\141\144\x76\145\x72\164\151\163\145\x72"; const qsoqogygekgcqgmw = "\x6f\x72\x67\141\x6e\x69\x7a\x65\137\x61\x64\166\x65\162\164\x69\163\x65"; }
