<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Interfaces; interface CommonInterface { const imeuqgwqyuywuwgm = "\162\145\147\151\163\164\145\x72\145\x64\137\157\x6e\x5f\150\x61\163\150\x75\162\145"; const uiiqamagukacsssy = "\x63\x73\x74\137\x68\x65\162\146\x65\150\x5f"; const yyigwaqioecwemiw = "\166\151\163\165\141\x6c"; const MEDIUM = "\155\x65\x64\151\x75\155"; const gcwcqmwwgiqsaame = "\x61\x75\144\151\x74\157\x72\x79"; const wsuusqigsoomsyky = "\x6d\x61\x67\141\172\x69\156\x65"; const seyosiicaqsgmuwa = "\x65\156\x67\x6c\x69\x73\150\137\141\x72\x74\x69\x63\154\145"; const uuseyckuwmiouskw = self::yyigwaqioecwemiw . "\x2d" . self::gcwcqmwwgiqsaame; const kaieokkoqukgmsea = "\141\162\164\151\x63\154\145\x5f\x63\x61\164\x65\147\157\x72\x79"; const aqmqeywcmyguggoo = "\145\x76\x65\x6e\x74"; const cqkewmmoacqamyce = "\x61\x64\x76\x65\x72\x74\151\163\x65"; const kueeagiqseeaeogs = "\x61\x64\166\x65\162\x74\151\x73\x65\x72"; const qsoqogygekgcqgmw = "\157\162\147\x61\x6e\151\x7a\x65\137\x61\x64\x76\145\162\164\151\x73\145"; }
