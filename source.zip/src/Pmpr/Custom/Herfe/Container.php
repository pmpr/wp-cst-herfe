<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a5d85e80d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\x68\x61\163\x68\x75\x72\145\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\x70\162\157\x64\x75\143\x74\137\x69\x64"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
