<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bd2e256d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\x68\141\x73\x68\x75\162\145\x5f"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\160\x72\157\144\165\143\x74\137\x69\144"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
