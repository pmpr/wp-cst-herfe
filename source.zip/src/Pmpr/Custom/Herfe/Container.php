<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bac701c5e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\x68\141\x73\x68\165\162\145\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\160\162\x6f\x64\165\x63\164\x5f\x69\x64"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
