<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92f25ffc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\150\x61\163\x68\165\162\x65\x5f"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\x70\x72\x6f\144\x75\143\164\x5f\x69\x64"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
