<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c4dccd5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Container extends BaseClass { const meuwgemwasqmoywm = "\x68\x61\163\x68\x75\x72\145\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . Constants::woicooamkeqiaemo; }
