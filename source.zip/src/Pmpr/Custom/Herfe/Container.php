<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\x68\x61\x73\x68\165\x72\x65\x5f"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\160\x72\x6f\x64\x75\x63\x74\x5f\x69\144"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
