<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\x68\141\163\x68\x75\x72\145\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\160\162\x6f\144\165\143\x74\x5f\x69\144"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
