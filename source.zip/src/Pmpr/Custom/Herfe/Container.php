<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\x68\141\x73\x68\x75\162\x65\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\160\x72\157\x64\165\x63\164\137\151\x64"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
