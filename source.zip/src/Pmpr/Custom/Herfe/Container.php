<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\x68\x61\x73\x68\165\x72\145\x5f"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\160\x72\x6f\144\x75\x63\164\x5f\151\144"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
