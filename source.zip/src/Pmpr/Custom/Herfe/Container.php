<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce711c12d1c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Container extends BaseClass { const meuwgemwasqmoywm = "\150\x61\x73\150\x75\x72\145\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . Constants::woicooamkeqiaemo; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
