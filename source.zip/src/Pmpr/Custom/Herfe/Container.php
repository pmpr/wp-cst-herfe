<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b9b5de1df             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; abstract class Container extends BaseClass implements CommonInterface { const meuwgemwasqmoywm = "\150\141\x73\150\x75\x72\145\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . "\160\162\157\144\x75\x63\x74\137\x69\144"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
