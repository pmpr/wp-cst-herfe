<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a5d85e80d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Process\Queue as BaseClass; use Pmpr\Custom\Herfe\Interfaces\CommonInterface; class Queue extends BaseClass implements CommonInterface { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group = self::uiiqamagukacsssy; } }
