<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f0256adc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise\CPT; use Pmpr\Custom\Herfe\Container; class CPT extends Container { public function mameiwsayuyquoeq() { Advertiser::symcgieuakksimmu(); Gallery::symcgieuakksimmu(); Event::symcgieuakksimmu(); } }
