<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { public function iwiyggkewesgioys() { $kieokceicuuaiuso = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ciugwooasaqcywas(self::kueeagiqseeaeogs, [], self::oyaoekcogwkcekcc); $ycuekasamuuasigw = null; if (!$kieokceicuuaiuso) { goto omugkkesagcyagmk; } $ycuekasamuuasigw = array_pop($kieokceicuuaiuso); omugkkesagcyagmk: return $ycuekasamuuasigw; } public function ucgqwmuigscaceuu() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return !$ewgmommeawggyaek->scmcyesmmikkucie(self::gewmeskawiqikkoc) && $ewgmommeawggyaek->scmcyesmmikkucie(self::kueeagiqseeaeogs); } }
