<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b57409bfc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { public function iwiyggkewesgioys() { $kieokceicuuaiuso = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ciugwooasaqcywas(self::kueeagiqseeaeogs, [], self::oyaoekcogwkcekcc); $ycuekasamuuasigw = null; if (!$kieokceicuuaiuso) { goto uougwgeyiokewkkm; } $ycuekasamuuasigw = array_pop($kieokceicuuaiuso); uougwgeyiokewkkm: return $ycuekasamuuasigw; } public function ucgqwmuigscaceuu() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return !$ewgmommeawggyaek->scmcyesmmikkucie(self::gewmeskawiqikkoc) && $ewgmommeawggyaek->scmcyesmmikkucie(self::kueeagiqseeaeogs); } }
