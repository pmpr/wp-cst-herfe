<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { public function iwiyggkewesgioys() { $kieokceicuuaiuso = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ciugwooasaqcywas(self::kueeagiqseeaeogs, [], self::oyaoekcogwkcekcc); $ycuekasamuuasigw = null; if (!$kieokceicuuaiuso) { goto qqewoyookaskiuek; } $ycuekasamuuasigw = array_pop($kieokceicuuaiuso); qqewoyookaskiuek: return $ycuekasamuuasigw; } public function ucgqwmuigscaceuu() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return !$ewgmommeawggyaek->scmcyesmmikkucie(self::gewmeskawiqikkoc) && $ewgmommeawggyaek->scmcyesmmikkucie(self::kueeagiqseeaeogs); } }
