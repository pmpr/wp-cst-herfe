<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d93046f12             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\144\137\x61\164\164\x61\x63\150\x6d\x65\156\164", [$this, "\x67\167\x6b\x6d\x6b\167\171\x65\157\151\145\147\141\171\143\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\141\x78\x5f\161\x75\145\162\171\137\141\x74\164\141\143\x68\155\x65\156\x74\163\137\141\x72\147\x73", [$this, "\151\171\x6f\151\x69\x65\x79\157\157\x71\x6b\x71\x77\x6d\x69\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
