<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ae14587c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x64\x5f\x61\164\x74\141\x63\150\x6d\145\x6e\x74", [$this, "\147\x77\153\x6d\x6b\x77\x79\145\157\151\145\x67\141\x79\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\141\x78\x5f\161\165\x65\x72\x79\x5f\141\164\x74\x61\143\x68\x6d\x65\x6e\x74\163\137\141\x72\x67\163", [$this, "\x69\171\157\x69\151\145\x79\157\157\161\153\x71\x77\155\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
