<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56b2cdf9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x64\137\x61\x74\x74\141\143\x68\155\145\x6e\164", [$this, "\147\x77\153\x6d\x6b\x77\x79\x65\x6f\x69\145\x67\x61\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\x61\x78\137\161\165\145\x72\171\x5f\141\x74\164\141\x63\150\155\145\x6e\x74\163\137\141\x72\147\x73", [$this, "\x69\x79\157\x69\x69\145\x79\157\157\x71\153\161\167\155\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto csammceowmqwaamq; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); csammceowmqwaamq: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto ocaguquugeamqckq; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\75"]]; ocaguquugeamqckq: return $gqgemcmoicmgaqie; } }
