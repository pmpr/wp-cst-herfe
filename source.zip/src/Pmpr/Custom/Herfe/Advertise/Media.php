<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a5d85e80d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\144\137\x61\x74\x74\x61\143\x68\155\145\156\164", [$this, "\x67\x77\153\155\x6b\167\x79\x65\x6f\151\x65\x67\x61\x79\143\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\141\x78\x5f\161\x75\x65\x72\x79\137\x61\164\164\141\143\150\155\145\x6e\164\163\137\x61\x72\147\x73", [$this, "\x69\171\157\x69\151\145\x79\157\157\x71\153\161\x77\155\151\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto gygwewcqsmwqismo; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); gygwewcqsmwqismo: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto uougwgeyiokewkkm; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\75"]]; uougwgeyiokewkkm: return $gqgemcmoicmgaqie; } }
