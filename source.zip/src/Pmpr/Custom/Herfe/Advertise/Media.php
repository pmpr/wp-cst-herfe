<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f0256adc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\144\137\x61\164\164\x61\x63\150\x6d\145\156\x74", [$this, "\147\x77\x6b\x6d\x6b\167\171\x65\157\151\145\x67\141\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\152\141\x78\137\161\x75\145\x72\171\x5f\x61\164\x74\141\x63\150\155\x65\x6e\x74\x73\x5f\x61\x72\147\163", [$this, "\151\x79\x6f\x69\151\145\x79\x6f\157\x71\153\x71\167\x6d\x69\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto csammceowmqwaamq; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); csammceowmqwaamq: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto ocaguquugeamqckq; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; ocaguquugeamqckq: return $gqgemcmoicmgaqie; } }
