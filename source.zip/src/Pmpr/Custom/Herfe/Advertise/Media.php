<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ed01b072             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\144\137\141\x74\164\x61\x63\150\x6d\145\x6e\x74", [$this, "\147\x77\153\155\x6b\167\x79\145\157\x69\x65\147\x61\171\143\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\x61\170\x5f\161\165\145\162\x79\137\141\164\164\x61\143\150\x6d\x65\x6e\x74\x73\137\x61\x72\147\163", [$this, "\x69\x79\157\151\151\x65\171\x6f\157\161\153\x71\x77\x6d\x69\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto qgegkeomwscwwiuw; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); qgegkeomwscwwiuw: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto qmiwsequckckoaei; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; qmiwsequckckoaei: return $gqgemcmoicmgaqie; } }
