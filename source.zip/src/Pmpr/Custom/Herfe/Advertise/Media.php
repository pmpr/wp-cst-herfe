<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bd2e256d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x64\137\141\164\164\141\x63\150\155\x65\x6e\164", [$this, "\147\x77\x6b\x6d\153\x77\171\x65\157\151\145\x67\141\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\x61\x78\x5f\x71\x75\x65\x72\x79\x5f\x61\x74\x74\141\143\150\155\145\156\164\163\x5f\141\x72\x67\x73", [$this, "\x69\x79\157\151\x69\145\171\157\x6f\x71\x6b\161\167\155\x69\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto ucqmumuygcywwqma; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); ucqmumuygcywwqma: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto uykousayyomcaeaa; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\75"]]; uykousayyomcaeaa: return $gqgemcmoicmgaqie; } }
