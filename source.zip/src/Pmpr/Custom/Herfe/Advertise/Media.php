<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a92f25ffc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\144\x5f\141\164\164\x61\143\150\155\x65\x6e\x74", [$this, "\147\167\x6b\x6d\153\x77\x79\x65\x6f\151\x65\x67\141\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\x61\x78\137\161\165\145\x72\171\x5f\x61\x74\164\141\143\150\155\145\156\164\x73\137\141\x72\147\163", [$this, "\x69\x79\157\x69\x69\145\x79\157\157\x71\153\x71\167\155\x69\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto ukqocwewouckikso; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); ukqocwewouckikso: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto ucqmumuygcywwqma; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; ucqmumuygcywwqma: return $gqgemcmoicmgaqie; } }
