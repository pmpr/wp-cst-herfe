<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b57409bfc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x64\x5f\x61\164\164\x61\x63\150\x6d\x65\156\164", [$this, "\147\x77\153\x6d\x6b\x77\171\x65\x6f\151\x65\x67\x61\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\x61\170\x5f\x71\x75\x65\x72\171\137\x61\x74\x74\x61\143\x68\155\x65\x6e\164\x73\x5f\x61\162\x67\x73", [$this, "\151\x79\x6f\151\x69\145\171\157\157\161\x6b\x71\167\x6d\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto gommacygsykyussk; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); gommacygsykyussk: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto ukqocwewouckikso; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; ukqocwewouckikso: return $gqgemcmoicmgaqie; } }
