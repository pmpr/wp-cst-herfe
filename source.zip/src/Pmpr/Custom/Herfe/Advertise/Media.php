<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707dc01428             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x64\x5f\141\164\x74\141\143\150\x6d\x65\156\164", [$this, "\147\167\x6b\x6d\153\x77\171\x65\x6f\x69\145\x67\141\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\x61\x78\137\x71\x75\x65\x72\171\137\141\164\164\x61\143\x68\x6d\145\x6e\164\x73\137\x61\x72\x67\x73", [$this, "\151\x79\157\x69\151\x65\171\x6f\157\x71\x6b\161\x77\x6d\x69\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto iwsuawwqomaowuii; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); iwsuawwqomaowuii: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto wcugqegqsuuuwqao; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; wcugqegqsuuuwqao: return $gqgemcmoicmgaqie; } }
