<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\144\x5f\x61\164\164\x61\x63\x68\x6d\x65\x6e\x74", [$this, "\147\167\x6b\x6d\x6b\x77\x79\145\157\151\145\147\x61\171\x63\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\x61\170\137\x71\165\145\162\171\137\x61\x74\x74\x61\143\150\x6d\145\156\x74\163\x5f\141\162\147\x73", [$this, "\x69\x79\x6f\x69\x69\145\x79\x6f\157\x71\x6b\x71\x77\x6d\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto iwsuawwqomaowuii; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); iwsuawwqomaowuii: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto wcugqegqsuuuwqao; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\75"]]; wcugqegqsuuuwqao: return $gqgemcmoicmgaqie; } }
