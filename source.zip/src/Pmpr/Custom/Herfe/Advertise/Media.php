<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed3b1eed             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\144\x5f\141\164\x74\x61\143\150\x6d\x65\156\x74", [$this, "\147\167\x6b\155\153\167\x79\145\x6f\151\145\147\141\x79\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\x61\170\x5f\161\x75\x65\162\171\137\141\x74\x74\141\143\x68\x6d\145\x6e\x74\163\137\141\162\x67\x73", [$this, "\x69\x79\x6f\x69\151\145\x79\157\157\x71\x6b\161\x77\155\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto ukqocwewouckikso; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); ukqocwewouckikso: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto ucqmumuygcywwqma; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; ucqmumuygcywwqma: return $gqgemcmoicmgaqie; } }
