<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e5372b91             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x64\x5f\141\164\x74\x61\x63\150\155\145\156\164", [$this, "\x67\167\x6b\x6d\153\x77\171\145\157\x69\x65\147\141\171\143\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\141\170\x5f\x71\165\145\x72\x79\x5f\141\x74\164\141\x63\x68\155\145\156\x74\x73\137\x61\162\147\163", [$this, "\151\x79\x6f\151\151\145\x79\157\157\161\153\x71\x77\x6d\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto mscgewkcqcoowweg; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); mscgewkcqcoowweg: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto suqcsgaosywaauuu; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\75"]]; suqcsgaosywaauuu: return $gqgemcmoicmgaqie; } }
