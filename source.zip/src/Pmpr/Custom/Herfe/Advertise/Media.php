<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b9b5de1df             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\144\x5f\x61\164\x74\x61\143\150\155\x65\x6e\164", [$this, "\147\167\x6b\155\x6b\x77\x79\145\157\151\x65\x67\x61\x79\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\x61\170\x5f\x71\x75\x65\x72\x79\x5f\141\164\x74\x61\x63\150\x6d\x65\156\x74\x73\137\x61\162\x67\x73", [$this, "\x69\x79\x6f\x69\151\x65\x79\157\x6f\161\153\161\167\155\151\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto gommacygsykyussk; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); gommacygsykyussk: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto ukqocwewouckikso; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\75"]]; ukqocwewouckikso: return $gqgemcmoicmgaqie; } }
