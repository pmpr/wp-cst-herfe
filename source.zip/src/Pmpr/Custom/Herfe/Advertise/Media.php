<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edca242c4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x64\137\141\x74\x74\x61\x63\x68\155\x65\156\x74", [$this, "\147\167\153\x6d\x6b\x77\x79\x65\x6f\151\145\147\x61\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\141\x78\x5f\161\165\x65\162\x79\x5f\x61\164\x74\141\x63\x68\155\x65\x6e\164\163\137\141\x72\x67\163", [$this, "\151\171\x6f\x69\x69\x65\171\x6f\157\161\153\161\167\155\x69\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto igymseewwyiocoug; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); igymseewwyiocoug: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto mqccmesakuemceqi; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; mqccmesakuemceqi: return $gqgemcmoicmgaqie; } }
