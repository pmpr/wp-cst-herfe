<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d24ec0e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\144\137\141\x74\x74\141\x63\x68\x6d\x65\156\x74", [$this, "\147\x77\153\155\x6b\x77\x79\145\157\x69\x65\x67\141\x79\143\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\x61\x78\137\x71\x75\145\x72\171\137\x61\x74\x74\x61\x63\150\155\x65\156\x74\163\137\141\x72\147\163", [$this, "\151\171\157\x69\151\145\171\157\157\x71\153\x71\167\x6d\151\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto csammceowmqwaamq; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); csammceowmqwaamq: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto ocaguquugeamqckq; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\75"]]; ocaguquugeamqckq: return $gqgemcmoicmgaqie; } }
