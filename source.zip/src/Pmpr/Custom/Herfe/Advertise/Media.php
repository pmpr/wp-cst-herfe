<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b0f6e10d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\144\x5f\x61\164\164\141\x63\x68\155\x65\156\164", [$this, "\147\167\x6b\x6d\153\x77\x79\145\x6f\x69\x65\x67\x61\x79\143\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\x61\x78\137\x71\165\145\x72\x79\x5f\141\x74\164\141\143\x68\155\145\156\x74\x73\x5f\x61\162\147\163", [$this, "\x69\x79\x6f\151\x69\145\x79\x6f\157\161\153\161\167\x6d\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto gygwewcqsmwqismo; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); gygwewcqsmwqismo: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto uougwgeyiokewkkm; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; uougwgeyiokewkkm: return $gqgemcmoicmgaqie; } }
