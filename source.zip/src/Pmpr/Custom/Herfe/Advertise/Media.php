<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x64\137\141\x74\x74\141\x63\150\155\145\x6e\164", [$this, "\147\x77\153\155\x6b\x77\x79\145\157\x69\x65\147\x61\171\143\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\141\170\x5f\x71\x75\x65\162\x79\137\141\x74\x74\x61\143\x68\155\x65\x6e\x74\163\x5f\141\x72\147\x73", [$this, "\x69\171\x6f\x69\x69\x65\x79\x6f\x6f\161\153\x71\167\155\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto iwsuawwqomaowuii; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); iwsuawwqomaowuii: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto wcugqegqsuuuwqao; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; wcugqegqsuuuwqao: return $gqgemcmoicmgaqie; } }
