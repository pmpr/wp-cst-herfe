<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e04ac0261             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x64\x5f\141\164\x74\x61\143\150\155\x65\156\164", [$this, "\147\167\x6b\155\153\x77\171\145\x6f\151\x65\147\x61\x79\x63\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\141\170\137\x71\x75\145\162\171\x5f\141\x74\164\141\143\x68\x6d\x65\156\x74\163\x5f\141\x72\147\x73", [$this, "\151\x79\157\x69\x69\145\x79\x6f\x6f\161\x6b\161\x77\155\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
