<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd820af53             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\144\x5f\141\164\164\x61\143\150\155\x65\156\164", [$this, "\147\x77\153\x6d\153\167\171\145\157\x69\145\147\x61\x79\x63\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\x61\x78\x5f\161\x75\145\x72\x79\137\x61\x74\x74\141\x63\150\155\145\x6e\x74\163\137\x61\162\x67\163", [$this, "\151\x79\x6f\x69\x69\x65\171\157\x6f\161\x6b\x71\x77\155\x69\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\x3d"]]; } return $gqgemcmoicmgaqie; } }
