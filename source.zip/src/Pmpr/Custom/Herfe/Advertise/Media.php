<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x64\137\x61\x74\164\141\143\x68\155\x65\x6e\164", [$this, "\147\167\x6b\155\x6b\167\171\145\x6f\151\x65\x67\141\x79\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\141\x78\x5f\161\x75\145\162\x79\x5f\141\164\164\141\x63\150\x6d\145\156\164\x73\137\x61\162\147\163", [$this, "\x69\171\x6f\151\151\x65\171\x6f\x6f\161\153\x71\x77\155\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if (!($aigsgikoosikweqa = $this->iwiyggkewesgioys())) { goto iwsuawwqomaowuii; } $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(self::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); iwsuawwqomaowuii: } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if (!$this->ucgqwmuigscaceuu()) { goto wcugqegqsuuuwqao; } $gqgemcmoicmgaqie[self::cuoyscoiacswuauq] = [[self::ascagqcquwgmygkm => self::kueeagiqseeaeogs, self::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), self::ykemsyouoqyoaysg => "\x3d"]]; wcugqegqsuuuwqao: return $gqgemcmoicmgaqie; } }
