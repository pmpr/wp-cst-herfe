<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c4dccd5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\144\137\141\164\164\x61\143\x68\155\x65\x6e\164", [$this, "\x67\x77\153\x6d\x6b\x77\171\x65\157\x69\145\x67\141\171\143\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\x61\170\x5f\161\x75\145\x72\x79\x5f\x61\164\164\x61\143\150\x6d\x65\x6e\164\163\137\141\162\147\x73", [$this, "\151\171\x6f\151\151\x65\x79\157\157\161\x6b\x71\x77\x6d\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
