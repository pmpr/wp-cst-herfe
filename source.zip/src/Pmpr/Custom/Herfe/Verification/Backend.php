<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f42c45f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Backend extends Common { }
