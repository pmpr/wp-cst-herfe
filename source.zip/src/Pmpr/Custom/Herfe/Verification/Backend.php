<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bac701c5e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Backend extends Common { }
