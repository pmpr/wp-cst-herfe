<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b9b5de1df             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x61\x73\x73\167\x6f\x72\x64\x5f\x72\145\163\145\x74", [$this, "\141\x6f\151\157\167\147\x6d\x69\x77\x75\x71\x6b\x69\x73\x75\x71"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
