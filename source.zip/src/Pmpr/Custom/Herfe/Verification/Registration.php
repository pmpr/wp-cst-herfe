<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646bd2e256d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\141\163\163\167\157\162\144\137\x72\x65\163\145\x74", [$this, "\141\157\151\157\x77\x67\x6d\x69\167\165\x71\153\151\163\165\161"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
