<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab86477dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\141\x73\x73\167\x6f\x72\x64\137\x72\145\x73\x65\x74", [$this, "\141\157\x69\157\x77\x67\155\151\x77\x75\x71\x6b\x69\163\x75\161"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
