<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d93046f12             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x61\163\x73\x77\x6f\162\x64\x5f\x72\x65\x73\x65\x74", [$this, "\x61\x6f\x69\157\167\147\155\x69\167\165\x71\x6b\151\x73\165\161"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
