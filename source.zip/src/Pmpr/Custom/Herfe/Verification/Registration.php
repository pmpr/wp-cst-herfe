<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a8d7dc5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\141\x73\x73\167\157\x72\x64\137\x72\x65\x73\145\x74", [$this, "\x61\157\x69\157\x77\x67\155\151\167\165\161\153\x69\163\165\161"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
