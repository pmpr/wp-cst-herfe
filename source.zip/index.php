<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e04ac0261             |
    |_______________________________________|
*/
 use Pmpr\Custom\Herfe\Herfe; Herfe::symcgieuakksimmu();
