<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce115ac0a49             |
    |_______________________________________|
*/
 use Pmpr\Custom\Herfe\Herfe; Herfe::symcgieuakksimmu();
