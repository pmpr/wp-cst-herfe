<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b57409bfc             |
    |_______________________________________|
*/
 use Pmpr\Custom\Herfe\Herfe; Herfe::symcgieuakksimmu();
